using Dashboard.Data;
using Dashboard.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;

namespace Dashboard.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private readonly ApplicationDbContext _context;

        public HomeController(ApplicationDbContext context)
        {
            _context = context;
        }


        [Authorize]
        public IActionResult Index()
        {
            var username = HttpContext.User.Identity.Name ?? null; // get user data
                                                                   // CookieOptions cookie = new CookieOptions(); // create in cookie
                                                                   // cookie.Expires = DateTime.Now.AddMinutes(100);// set time
                                                                   // Response.Cookies.Append("userdata", username, cookie); // store user data in cookie

            HttpContext.Session.SetString("userdata", username);
            ViewBag.Username = username;
            //  ViewBag.Username = Request.Cookies["userdata"]; // get user data from cookie

            return View();
        }

        //public IActionResult CreateProducts(Products products)
        //{
        //    _context.Add(products);
        //    _context.SaveChanges();

        //    return RedirectToAction("AddNewItem");

        //}

        public IActionResult Home(Products products)
        {
            _context.Add(products);
            _context.SaveChanges();

            return RedirectToAction("Index");

        }
        // -----------------------------------------------------------------


        public IActionResult Demag()
        {
            ViewBag.Username = HttpContext.Session.GetString("userdata");
            var products = _context.product.ToList();

            var Productsdemage = _context.damageProductsDetails.Join
                (
                     _context.product,

                      demag => demag.ProductId,
                      products => products.Id,


                     (demag, products) => new
                     {
                         demag,
                         products
                     }

                ).Join
                (
                  _context.productsDetails,

                  p => p.demag.ProductId,
                  c => c.ProductId,

                  (p, c) => new
                  {
                      id = p.demag.Id,
                      name = p.products.Name,
                      color = c.Color,
                      qty = p.demag.Qty
                  }
                  ).ToList();

            Console.WriteLine($"{Productsdemage}");


            ViewBag.products = products;
            ViewBag.damage = Productsdemage;

            return View();
        }

        //-----------------------------------------------------------

        public IActionResult AddNewItem()
{
            // ViewBag.Username = Request.Cookies["userdata"];
            ViewBag.Username = HttpContext.Session.GetString("userdata");
            return View();
        }


        //public IActionResult ProductDetails()
        //{
        //    var ProductsDetails = _context.product.ToList();
        //    var product = _context.product.ToList();
        //    //  ViewBag.ProductDetails = ProductsDetails;
        //    ViewBag.product = product;
        //    return View(ProductsDetails);
        //}


        public IActionResult ProductDetails(int name)
        {
            // Retrieve the specific product by its ID
            var product = _context.product.FirstOrDefault(p => p.Name == name);

            if (product == null)
            {
                // Return a 404 Not Found response if the product is not found
                return NotFound();
            }

            // Pass the product object to the view
            return View(product);
        }
        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}

