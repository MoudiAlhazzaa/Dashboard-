﻿
//function AddNewItem() {
//    $("#newproducts").modal("show");
//}

//function AddNewDemag() {
//    $("#demag").modal("show");
//}

