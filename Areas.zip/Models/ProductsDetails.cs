﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Dashboard.Models
{
    public class ProductsDetails
    {
        [Key]
        public int Id { get; set; }

        
        [StringLength(20)]
        public string Color { get; set; }

        
        [StringLength(100)]
        public string Qty { get; set; }

        
        [StringLength(100)]
        public string Image { get; set; }

        
        [StringLength(20)]
        public float Price { get; set; }

        public int ProductId { get; set; }

    }
}
