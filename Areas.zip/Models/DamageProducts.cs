﻿using System.ComponentModel.DataAnnotations;

namespace Dashboard.Models
{
    public class DamageProducts
    {
        [Key]
        public int Id { get; set; }

        public string Qty { get; set; }

        public int ProductId { get; set; }
    }
}
